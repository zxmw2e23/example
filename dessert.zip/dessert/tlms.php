<?php
$flag=$_GET['flag'];
$username=$_GET['username'];
?>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css"  href="form.css" />
				<script type="text/javascript" src="search.js"></script>
	</head>
	<body style="background: url(./images/bgc6.jpg); center;background-size:100% 100%;
background-attachment:fixed;">
			
		<form >
			<img src="./images/dbblogo.jpg" style="width: 100px;position: absolute;" />
			<div class="divtop">
			
				<a href="callme.php?flag=<?php echo $flag;?>&name=<?php echo $row['name']; ?>&username=<?php echo $username ;?>" class="a_button1"><input type="button" value="联系我们" class="button1" ></a><a href="index_form.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>" class="a_button2"><input type="button" class="button2" value="全部商品"></a>
				<div class="fenlei"><input type="button" class="sn" value="商品分类▼">
					<ul>
						<a href="tlms.php?flag=<?php echo $flag;?>&name=<?php echo $row['name']; ?>&username=<?php echo $username ;?>"><li>提拉米苏</li></a>
						<a href="bzdg.php?flag=<?php echo $flag;?>&name=<?php echo $row['name']; ?>&username=<?php echo $username ;?>"><li>杯子蛋糕</li></a>
						<a href="qianceng.php?flag=<?php echo $flag;?>&name=<?php echo $row['name']; ?>&username=<?php echo $username ;?>"><li>千层</li></a>
						<a href="dxdg.php?flag=<?php echo $flag;?>&name=<?php echo $row['name']; ?>&username=<?php echo $username ;?>"><li>大型蛋糕</li></a>
					
					</ul>
				</div>
				
				
			</div>
			<?php
				if($flag==0){
					
				
			?>
			<div class="own_2">
				<a href="login_form.php">用户登录</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="register_form.php">用户注册</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="manager_login_form.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>">管理员登录</a>
			</div>
			<?php
				}else{
					
			?>
			<div class="own_2">
				<a href="change_info_form.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>">个人信息</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index_form.php">退出登录</a>
			</div>
				<?php } ?>
			<div class="divbody">
				<table class="body_table" border="0" cellspacing="1px">
					<tr><th style="width:300px;">商品实图</th><th>商品名称</th><th>类别</th><th>数量</th><th>价格</th><th>操作</th></tr>
<?php
	$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	
	
	$result=mysqli_query($link,"select * from dessert where d_type like '%提拉米苏%'");
	
	while($row=mysqli_fetch_assoc($result)){
							?>
							<tr>
							<td><img src="images\<?php echo $row['image']; ?>"	style="width:150px;" /></td>
							<td><p><?php echo $row['name']; ?></p></td>
							<td><p><?php echo $row['d_type']; ?></p></td>
							<td><p><?php echo $row['number']; ?></p></td>
							<td><p><?php echo $row['price']; ?></p></td>
							<?php
							if($flag==1){
							?>
							<td style="width: 200px;"><a href="goumai.php?flag=<?php echo $flag;?>&name=<?php echo $row['name']; ?>&username=<?php echo $username ;?>"><input type="button" class="button_gm" value="购买"></a></td>
							<?php }else{
								?>
								<td><p>请先登录，才能购买</p> </td>
							</tr>
							<?php
							}
						}
	
	
?>
</table>
			</div>
		</form>
		<form action="search.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>" method="post">
					<div class="search" style="margin-top:-40px;position:absolute;">
						<input type="text" name="search" id="search" placeholder="输入商品名称"/>
						<input type="submit" style="width:70px;height: 27px;" value="搜索商品">
					</div>
				</form>
	</body>
</html>