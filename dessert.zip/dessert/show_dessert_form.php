<?php
$manager_name=$_GET['manager_name'];
$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	$page=isset($_GET['cPage'])? $_GET['cPage']:1;
?>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css"  href="manager.css" />
	</head>
	<body style="background: url(./images/manbgc.jpg); center;background-size:100% 100%;
background-attachment:fixed;">
<div class="divtop">
	<p class="p1">DBB甜品店后台管理系统</p>
	<a href="manager_form.php?manager_name=<?php echo $manager_name;?>" class="a_1"><input type="button" class="button1" id="button1" value="首页" ></a>
	
			<div class="guanli"><input type="button" id="button2" class="sn" value="商品管理▼" style="background-color: #BDBDBD;">
				<ul>
					<a id="ck1" href="show_dessert_form.php?manager_name=<?php echo $manager_name;?>"><li>查看商品</li></a>
					<a id="tj1" href="insert_dessert_form.php?manager_name=<?php echo $manager_name;?>"><li>添加商品</li></a>
					<a id="xj" href="delete_dessert_form.php?manager_name=<?php echo $manager_name;?>"><li>下架商品</li></a>
				</ul>
			</div>
		<div class="guanli2">
			<input type="button" class="sn" id="button3" value="用户管理▼">
			<ul>
				<a id="ck2" href="show_user_form.php?manager_name=<?php echo $manager_name;?>"><li>查看用户</li></a>
				<a id="tj2" href="insert_user_form.php?manager_name=<?php echo $manager_name;?>"><li>添加用户</li></a>
				<a id="sc" href="delete_user_form.php?manager_name=<?php echo $manager_name;?>"><li>删除用户</li></a>
			</ul>
		</div>
	<a href="change_manpwd_form.php?manager_name=<?php echo $manager_name;?>"class="a_4"><input type="button" class="button3" id="button4" value="更改管理员密码"></a>
	<a href="manager_login_form.php" style="margin:15px 0 0 1250px;position: absolute;text-decoration: none;color: #6d6d6d;">退出登录</a>
	
</div>
		<div class="divbody">
			<table class="body_table" border="0" cellspacing="1px">
				<tr><th style="width:300px;">商品实图</th><th>商品名称</th><th>类别</th><th>数量</th><th>价格</th></tr>
				<?php $result1=mysqli_query($link,"select * from dessert limit ".($page-1) * 5 .",5 ");
					while($row=mysqli_fetch_assoc($result1)){
						?>
						<tr>
						<td><img src="images\<?php echo $row['image']; ?>"	style="width:150px;height:100px;" /></td>
						<td><p><?php echo $row['name']; ?></p></td>
						<td><p><?php echo $row['d_type']; ?></p></td>
						<td><p><?php echo $row['number']; ?></p></td>
						<td><p><?php echo $row['price']; ?></p></td>
						
					<?php
					}
					mysqli_free_result($result1);
					$result= mysqli_query($link,"select count(*)from dessert");
					$row=mysqli_fetch_array($result);
					$count=$row[0];
					$to_pages=ceil($count/5);
					
					echo "<div class='fy'>";
					if($page<=1){
						echo "<a href='".$_SERVER['PHP_SELF']."?cPage=1&manager_name=".$manager_name."'>首页</a>";
					    echo "<a href='".$_SERVER['PHP_SELF']."?cPage=1&manager_name=".$manager_name."'>上一页</a>";
					}else{
						echo "<a href='".$_SERVER['PHP_SELF']."?cPage=1&manager_name=".$manager_name."'>首页</a>";
					    echo "<a href='".$_SERVER['PHP_SELF']."?cPage=".($page-1)."&manager_name=".$manager_name."'>上一页</a>";
					}
					if ($page<$to_pages){
					    echo "<a href='".$_SERVER['PHP_SELF']."?cPage=".($page+1)."&manager_name=".$manager_name."'>下一页</a>";
						echo "<a href='".$_SERVER['PHP_SELF']."?cPage=".($to_pages)."&manager_name=".$manager_name."'>尾页</a>";
					}else{
					    echo "<a href='".$_SERVER['PHP_SELF']."?cPage=".($to_pages)."&manager_name=".$manager_name."'>下一页</a>";
						echo "<a href='".$_SERVER['PHP_SELF']."?cPage=".($to_pages)."&manager_name=".$manager_name."'>尾页</a>";
					}
					echo "</div>";
						
				?>
			</table>
		</div>
				</body>
			</html>
			