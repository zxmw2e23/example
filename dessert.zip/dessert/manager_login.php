<?php
$a=$_GET['a'];
$flag=$_GET['flag'];
$username=$_GET['username'];
$name=$_GET['name'];
$manager_name=$_POST['manager_name'];
$manager_pwd=$_POST['manager_pwd'];
	$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	$result=mysqli_query($link,"select * from dessert_manager where username='".$manager_name."' and password='".$manager_pwd."'");
	$query=mysqli_num_rows($result);
	if(!$query){
		exit("<script>
				alert('用户名或密码有误，请重新填写');
				location.href='manager_login_form.php';
			</script>");
	}
	
	exit("<script>
				alert('登录成功');
				location.href='manager_form.php?manager_name=".$manager_name."';
			</script>");

		
?>