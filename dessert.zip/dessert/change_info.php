<?php
$flag=$_GET['flag'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$telephone=$_POST['telephone'];
	$address=$_POST['address'];
	$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	
?>
