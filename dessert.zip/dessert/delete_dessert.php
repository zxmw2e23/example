<?php
$flag=$_GET['flag'];
$username=$_GET['username'];
$name=$_POST['name'];
$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	if(!$name){
		exit( "<script language=\"JavaScript\">alert(\"商品名称不能为空，请继续填写\");	location.href='delete_dessert_form.php?flag=".$flag."&username=".$username."';</script>");
	}
	$result=mysqli_query($link,"select * from dessert where name='".$name."'");
	$query=mysqli_num_rows($result);
	if($query==0){
		exit( "<script language=\"JavaScript\">alert(\"次商品不存在，请重新填写\");	location.href='delete_dessert_form.php?flag=".$flag."&username=".$username."';</script>");
	}
	if(!mysqli_query($link,"delete from dessert where name='".$name."' ")){
		exit( "<script language=\"JavaScript\">alert(\"下架商品失败，请重新填写\");	location.href='delete_dessert_form.php?flag=".$flag."&username=".$username."';</script>");
	}
	exit( "<script language=\"JavaScript\">alert(\"下架商品成功\");	location.href='delete_dessert_form.php?flag=".$flag."&username=".$username."';</script>");
?>