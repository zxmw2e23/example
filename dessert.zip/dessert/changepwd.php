<?php
$flag=$_GET['flag'];
$username=$_GET['username'];
$newpwd=$_POST['password'];
$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	if(mysqli_query($link,"select * from dessert_user where username='".$username."'")){
		if(mysqli_query($link,"update dessert_user set password ='".$newpwd."' where username='".$username."'")){
			exit("<script>
					alert('修改密码成功');
					location.href='change_info_form.php?flag=".$flag."&username=".$username."';
				</script>");
		}
	}
	exit("<script>
					alert('修改密码失败，请重新填写!');
					location.href='changepwd_form.php?flag=".$flag."&username=".$username."';
				</script>");
?>