<?php
$manager_name=$_GET['manager_name'];
$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	$result=mysqli_query($link,"select * from dessert_manager where username='".$manager_name."'");
	
	$query=mysqli_fetch_assoc($result);
	$image=$query['image'];
	
?>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css"  href="manager.css" />
		<script src="button.js"></script>
	</head>
	<body style="background: url(./images/manbgc.jpg); center;background-size:100% 100%;
background-attachment:fixed;">
<div class="divtop">
	<p class="p1">DBB甜品店后台管理系统</p>
	<a href="manager_form.php?manager_name=<?php echo $manager_name; ?>" class="a_1"><input type="button" class="button1" id="button1" value="首页" style="background-color: #BDBDBD;"></a>
	
			<div class="guanli"><input type="button" id="button2" class="sn" value="商品管理▼">
				<ul>
					<a id="ck1" href="show_dessert_form.php?manager_name=<?php echo $manager_name;?>"><li>查看商品</li></a>
					<a id="tj1" href="insert_dessert_form.php?manager_name=<?php echo $manager_name;?>"><li>添加商品</li></a>
					<a id="xj" href="delete_dessert_form.php?manager_name=<?php echo $manager_name;?>"><li>下架商品</li></a>
				</ul>
			</div>
		<div class="guanli2">
			<input type="button" class="sn" id="button3" value="用户管理▼">
			<ul>
				<a id="ck2" href="show_user_form.php?manager_name=<?php echo $manager_name;?>"><li>查看用户</li></a>
				<a id="tj2" href="insert_user_form.php?manager_name=<?php echo $manager_name;?>"><li>添加用户</li></a>
				<a id="sc" href="delete_user_form.php?manager_name=<?php echo $manager_name;?>"><li>删除用户</li></a>
			</ul>
		</div>
		<a href="change_manpwd_form.php?manager_name=<?php echo $manager_name;?>"class="a_4"><input type="button" class="button3" id="button4" value="更改管理员密码"></a>
		<a href="manager_login_form.php" style="margin:15px 0 0 1250px;position: absolute;text-decoration: none;color: #6d6d6d;">退出登录</a>
		</div>
		<form action="insert_user.php?manager_name=<?php echo $manager_name;?>" method="post">
				<table class="regi_table">
					<tr><td><h2 style>添加用户</h2></td></tr>
					<tr><td><p>用户名:</p></td><td><input type="text" name="username"></td></tr>
					<tr><td><p>密码:</p></td><td><input type="text" name="password"></td></tr>
					<tr><td><p>电话号:</p></td><td><input type="text" name="telephone"></td></tr>
					<tr><td><p>住址:</p></td><td><input type="text" name="address"></td></tr>	
					
					<tr><td><input type="submit" class="tianjia" value="添加" style="background-color: #2EFEF7"></td><td><input type="reset" class="tianjia" value="重置" style="background-color: #FE9A2E"/></td></tr>
				<table>
			</form>
		</body>
		</html>