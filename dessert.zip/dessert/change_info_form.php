<?php
$flag=$_GET['flag'];
$username=$_GET['username'];
$page=isset($_GET['cPage'])? $_GET['cPage']:1;
$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	$result=mysqli_query($link,"select * from dessert_user where username='".$username."'");
	if(!$result){
		exit("<script>
			alert('查询失败');
			location.href='index_form.php?flag=".$flag."&username=".$username."';
		</script>");
	}
	$query=mysqli_fetch_assoc($result);
	$uname=$query['username'];
	$password=$query['password'];
	$telephone=$query['telephone'];
	$address=$query['address'];
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css" href="form.css" />	
	</head>
	<body style="background: url(./images/regist5.jpg) center;background-size:100% 100%;
background-attachment:fixed;">
		<form action="#" method="post">
			<a href="index_form.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>" style="text-decoration: none;"><h2>←返回主页<h2></a>
				<table class="change_table">
					<tr><td><h2 style="margin:-40px 0 0 70px;position:absolute">用户信息</h2></td></tr>
					<tr><td><p>用户名：</p></td><td><?php echo $uname;?></td><td><a href="changeuname_form.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>">点击修改用户名</a></td></tr>
					<tr><td><p>密&nbsp;&nbsp;&nbsp;码：</p></td><td><?php echo $password;?></td><td><a href="changepwd_form.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>">点击修改密码</a></tr>
					<tr><td><p>手机号：</p></td><td><?php echo $telephone;?></td><td><a href="changetele_form.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>">点击修改手机号</a></tr>
					<tr><td><p>地&nbsp;&nbsp;&nbsp;址：</p></td><td><?php echo $address;?></td><td><a href="changeaddress_form.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>">点击修改地址</a></tr>
				<table>
				<hr style="margin-bottom:-10px">
				<p style="color:#FF8000;margin: 50px 0 0 100px;font-size:30px;">已购买的商品</p>
				<hr style="margin-bottom:-20px;">
				<table class="change_table_2" border="0" cellspacing="1px">
					<tr><th style="width:300px;">商品实图</th><th>商品名称</th><th>类别</th><th>数量</th><th style="width:150px;">操作</th></tr>
				<?php $result1=mysqli_query($link,"select * from ".$username." limit ".($page-1) * 5 .",5 ");
						while($row=mysqli_fetch_assoc($result1)){
							?>
							<tr>
							<td><img src="images\<?php echo $row['image']; ?>"	style="width:150px;" /></td>
							<td><p><?php echo $row['name']; ?></p></td>
							<td><p><?php echo $row['d_type']; ?></p></td>
							<td><p><?php echo $row['number']; ?></p></td>
							
							<td style="width: 200px;"><a href="tuihuo.php?flag=<?php echo $flag;?>&name=<?php echo $row['name']; ?>&username=<?php echo $username ;?>">退货</a></td></tr>
							
							<?php
							}
						?>
			</form>
				</body>
			</html>
			