/*
SQLyog v10.2 
MySQL - 5.0.96-community-nt : Database - dbb_dessert
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbb_dessert` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `dbb_dessert`;

/*Table structure for table `dbb` */

DROP TABLE IF EXISTS `dbb`;

CREATE TABLE `dbb` (
  `name` varchar(60) default NULL,
  `d_type` varchar(60) default NULL,
  `number` int(10) default NULL,
  `price` double default NULL,
  `image` varchar(60) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `dbb` */

insert  into `dbb`(`name`,`d_type`,`number`,`price`,`image`) values ('蜜雪','杯子蛋糕',1,8,'密雪.jpg');

/*Table structure for table `dessert` */

DROP TABLE IF EXISTS `dessert`;

CREATE TABLE `dessert` (
  `name` varchar(20) default NULL,
  `d_type` varchar(20) default NULL,
  `number` int(10) default NULL,
  `price` double default NULL,
  `image` varchar(150) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `dessert` */

insert  into `dessert`(`name`,`d_type`,`number`,`price`,`image`) values ('暗恋','提拉米苏',6,20,'anlian.jpg'),('奶油童话','提拉米苏',9,21,'nyth.jpg'),('甜蜜时刻','提拉米苏',9,22,'tmsk.jpg'),('洛可可','杯子蛋糕',9,6.5,'洛可可.jpg'),('蜜雪','杯子蛋糕',9,8,'密雪.jpg'),('童话味蕾','杯子蛋糕',10,10,'童话味蕾.jpg'),('甜在心扉','杯子蛋糕',13,9,'甜在心扉.jpg'),('闲趣','杯子蛋糕',10,10,'闲趣.jpg'),('草莓千层','千层',5,15,'草莓千层.jpg'),('黑巧千层','千层',6,20,'黑巧千层.jpg'),('夹心千层','千层',5,15,'夹心千层.jpg'),('巧克力千层','千层',7,12,'巧克力千层.jpg'),('贝蒂','大型蛋糕',3,80,'贝蒂.jpg'),('草莓甜心','大型蛋糕',2,70,'草莓甜心.jpg'),('黑森林切块','大型蛋糕',5,50,'黑森林切块.jpg'),('倾城时光','大型蛋糕',2,100,'倾城时光.jpg'),('树莓慕斯','大型蛋糕',3,110,'树莓慕斯.jpg'),('午夜玫瑰','大型蛋糕',2,90,'午夜玫瑰.jpg');

/*Table structure for table `dessert_manager` */

DROP TABLE IF EXISTS `dessert_manager`;

CREATE TABLE `dessert_manager` (
  `username` varchar(10) NOT NULL,
  `password` varchar(16) NOT NULL,
  `image` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `dessert_manager` */

insert  into `dessert_manager`(`username`,`password`,`image`) values ('binglaoban','123456','manbgc2.jpg');

/*Table structure for table `dessert_user` */

DROP TABLE IF EXISTS `dessert_user`;

CREATE TABLE `dessert_user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `telephone` varchar(11) NOT NULL,
  `address` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `dessert_user` */

insert  into `dessert_user`(`username`,`password`,`telephone`,`address`) values ('zhangsan','147258369','123456789','邯郸学院'),('dbb','147258369','123456789','nicai');

/*Table structure for table `own_dessert` */

DROP TABLE IF EXISTS `own_dessert`;

CREATE TABLE `own_dessert` (
  `name` varchar(20) NOT NULL,
  `d_type` varchar(20) NOT NULL,
  `number` int(10) NOT NULL,
  `price` double NOT NULL,
  `image` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `own_dessert` */

insert  into `own_dessert`(`name`,`d_type`,`number`,`price`,`image`) values ('暗恋','提拉米苏',5,20,'anlian.jpg'),('奶油童话','提拉米苏',1,21,'nyth.jpg'),('暗恋','提拉米苏',1,20,'anlian.jpg'),('暗恋','提拉米苏',1,20,'anlian.jpg'),('暗恋','提拉米苏',1,20,'anlian.jpg'),('奶油童话','提拉米苏',1,21,'nyth.jpg'),('蜜雪','杯子蛋糕',1,8,'密雪.jpg'),('蜜雪','杯子蛋糕',1,8,'密雪.jpg'),('蜜雪','杯子蛋糕',1,8,'密雪.jpg'),('蜜雪','杯子蛋糕',1,8,'密雪.jpg'),('蜜雪','杯子蛋糕',1,8,'密雪.jpg');

/*Table structure for table `photo` */

DROP TABLE IF EXISTS `photo`;

CREATE TABLE `photo` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `type` varchar(100) character set latin1 NOT NULL,
  `binarydata` mediumblob NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `photo` */

insert  into `photo`(`id`,`type`,`binarydata`) values (1,'images\\anlian.jpg','');

/*Table structure for table `zhangsan` */

DROP TABLE IF EXISTS `zhangsan`;

CREATE TABLE `zhangsan` (
  `name` varchar(60) default NULL,
  `d_type` varchar(60) default NULL,
  `number` int(10) default NULL,
  `price` double default NULL,
  `image` varchar(60) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `zhangsan` */

insert  into `zhangsan`(`name`,`d_type`,`number`,`price`,`image`) values ('暗恋','提拉米苏',2,20,'anlian.jpg');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
