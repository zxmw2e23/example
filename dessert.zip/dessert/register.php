<?php
	$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	$username=$_POST['username'];
	$password=$_POST['password'];
	$telephone=$_POST['telephone'];
	$address=$_POST['address'];
	
	if($username==null||$password==null||$telephone==null||$address==null){
		exit( "<script language=\"JavaScript\">alert(\"表单未填写完毕，请继续填写\");history.back();</script>");
	}
	$result1=mysqli_query($link,"select username from dessert_user where username='".$username."'");
	$query=mysqli_fetch_assoc($result);
	$username1=$query['username'];
	if($username==$username1){
		exit( "<script language=\"JavaScript\">alert(\"用户名已存在，请重新填写\");location.href='register_form.php'</script>");
	}
	if(mysqli_query($link,"insert into dessert_user values ('$username','$password','$telephone','$address')")){
		$sql="CREATE TABLE `".$username."` (
		`name` VARCHAR (60),
		`d_type` VARCHAR (60),
		`number` INT (10),
		`price` DOUBLE ,
		`image` VARCHAR (60)
		); 
		";
		if(!mysqli_query($link,$sql)){
			exit("<script language=\"JavaScript\">alert(\"注册失败，请重新填写\");history.back();</script>");
		}
		exit("<script>alert('注册成功');location.href='login_form.php'</script>");
		
	}
	exit( "<script language=\"JavaScript\">alert(\"注册失败，请重新填写\");history.back();</script>");	
?>