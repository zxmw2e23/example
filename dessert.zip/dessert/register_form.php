<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css" href="form.css" />	
	</head>
	<body style="background: url(./images/regist5.jpg) center;background-size:100% 100%;
background-attachment:fixed;">
		<form action="register.php" method="post">
			<a href="index_form.php" style="text-decoration: none;margin:150px 0 0 200px;"><h2>←返回主页<h2></a>
			
				<table class="regi_table">
					<tr><td><h2 style>用户注册</h2></td></tr>
					<tr><td><p>用户名:</p></td><td><input type="text" name="username"></td></tr>
					<tr><td><p>密&nbsp;&nbsp;&nbsp;码:</p></td><td><input type="password" name="password"></td></tr>
					<tr><td><p>手机号:</p></td><td><input type="text" name="telephone"></td></tr>
					<tr><td><p>地&nbsp;&nbsp;&nbsp;址:</p></td><td><input type="text" name="address"></td></tr>	
					<tr><td><input type="submit" class="tianjia" value="注册"></td><td><input type="reset" class="tianjia" value="重置"/></td></tr>
				<table>
			</form>
				</body>
			</html>
			