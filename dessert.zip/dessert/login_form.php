<?php
$flag=$_GET['flag'];
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css" href="form.css" />	
	</head>
	<body style="background: url(./images/regist5.jpg) center;background-size:100% 100%;
background-attachment:fixed;">
		<form action="login.php?flag=<?php echo $flag;?>" method="post">
			<a href="index_form.php?flag=<?php echo $flag;?>" style="text-decoration: none;margin:150px 0 0 200px;"><h2>←返回主页<h2></a>
			
				<table class="login_table">
					<tr><td><h2 style="margin-left:50px;">用户登录</h2></td></tr>
					<tr><td><p>用户名:</p></td><td><input type="text" name="username"></td></tr>
					<tr><td><p>密&nbsp;&nbsp;&nbsp;码:</p></td><td><input type="password" name="password"></td></tr>
					<tr><td><input type="submit" class="tianjia" value="登录" style="margin-left:100px;position:absolute"></td></tr>
				<table>
			</form>
				</body>
			</html>
			