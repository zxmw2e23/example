
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css" href="form.css" />	
	</head>
	<body style="background: url(./images/regist5.jpg) center;background-size:100% 100%;
background-attachment:fixed;">
		<form action="manager_login.php?&manager_name=manager_name&a=<?php echo $a;?>&flag=<?php echo $flag;?>&username=<?php echo $username ;?>" method="post">
			<a href="index_form.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>&a=<?php echo $a;?>" style="text-decoration: none;"><h2>←返回主页<h2></a>
			<table style="margin:200px 0 0 800px;line-height:50px;font-size:20px;">
			<tr><td><p style="margin:-60px 0 0 50px; position:absolute;font-size:30px;">管理员登录</p></td></tr>
				<tr><td>用户名:</td><td><input type="text" name="manager_name"></td></tr>
				<tr><td>密码:</td><td><input type="text" name="manager_pwd"></td></tr>
				<tr><td><input type="submit" value="登录" style="margin:20px 0 0 100px;position:absolute;width:50px;height:30px;"></td></tr>
			</table>
			</form>
				</body>
			</html>