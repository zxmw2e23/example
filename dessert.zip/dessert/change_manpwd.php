<?php
$manager_name=$_GET['manager_name'];
$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	$oldpwd=$_POST['oldpwd'];
	echo $oldpwd;
	
	$newpwd=$_POST['newpwd'];
	echo $newpwd;
	if(!$oldpwd||!$newpwd){
		exit("<script>
						alert('表单填写不完全,请继续填写');
						location.href='change_manpwd_form.php?manager_name=".$manager_name."';
					</script>");
	}
	$result=mysqli_query($link,"select * from dessert_manager where username='".$manager_name."' and password='".$oldpwd."'");
	
	if(!$result){
		exit("<script>
						alert('密码认证失败,请重新填写');
						location.href='change_manpwd_form.php?manager_name=".$manager_name."';
					</script>");
	}
	if(!mysqli_query($link,"update dessert_manager set password='".$newpwd."'")){
		exit("<script>
						alert('更改管理员密码失败,请重新填写');
						location.href='change_manpwd_form.php?manager_name=".$manager_name."';
					</script>");
	}
	exit("<script>
					alert('更改管理员密码成功');
					location.href='change_manpwd_form.php?manager_name=".$manager_name."';
				</script>");
?>