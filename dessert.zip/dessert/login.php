<?php
$flag=$_GET['flag'];
$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	$username=$_POST['username'];
	$password=$_POST['password'];
	$flag=true;
	if(!$username||!$password){
		exit("<script>alert('用户名或密码不能为空，请重新填写');location.href='login_form.php?flag=".$flag."'</script>");
	}
	$result=mysqli_query($link,"select * from dessert_user where username='".$username."' and password='".$password."'");
	$query=mysqli_fetch_assoc($result);
	$uname=$query['username'];
	$pwd=$query['password'];
	if($uname==null&&$pwd==null){
			$flag=false;
		exit("<script>alert('登陆失败，用户名或密码错误');location.href='login_form.php?flag=".$flag."'</script>");
	}

	exit("<script>alert('登录成功');location.href='index_form.php?flag=".$flag."&username=".$username."'</script>");
	
	?>