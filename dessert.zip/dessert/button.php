<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
	</head>
	<body>
		<a><input type="button" class="button" id="button1" value="首页"></a>
		<a><input type="button" class="button" id="button2" value="首页"></a>
		<a><input type="button" class="button" id="button3" value="首页"></a>
		<a><input type="button" class="button" id="button4" value="首页"></a>
		<script>
			var btn1=document.getElementById("button1");
			var btn2=document.getElementById("button2");
			var btn3=document.getElementById("button3");
			var btn4=document.getElementById("button4");
			
			
			btn1.onclick = function(){
					
				btn1.style.backgroundColor = "red";
				btn2.style.backgroundColor = "";
				btn3.style.backgroundColor = "";
				btn4.style.backgroundColor = "";
					
			}
			btn2.onclick=function(){
				btn1.style.backgroundColor = "";
				btn2.style.backgroundColor = "red";
				btn3.style.backgroundColor = "";
				btn4.style.backgroundColor = "";
			}
			btn3.onclick=function(){
				btn1.style.backgroundColor = "";
				btn2.style.backgroundColor = "";
				btn3.style.backgroundColor = "red";
				btn4.style.backgroundColor = "";
			}
			btn4.onclick=function(){
				btn1.style.backgroundColor = "";
				btn2.style.backgroundColor = "";
				btn3.style.backgroundColor = "";
				btn4.style.backgroundColor = "red";
			}
		</script>
	</body>
</html>
