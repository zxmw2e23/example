<?php
$flag=$_GET['flag'];
$name=$_GET['name'];
$username=$_GET['username'];
	$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	
		$result=mysqli_query($link,"select * from dessert where name='".$name."'");
		$result1=mysqli_query($link,"select * from ".$username." where name='".$name."'");
		if(!mysqli_query($link,"select * from ".$username."")){
			exit("<script>
				alert('失败');
				location.href='index_form.php?flag=".$flag."&username=".$username."';
			</script>");
		}
		$query2=mysqli_num_rows($result1);
		$query1=mysqli_fetch_assoc($result1);
		$unumber=$query1['number'];
		$query=mysqli_fetch_assoc($result);
		$dname=$query['name'];
		$dtype=$query['d_type'];
		$dnumber=$query['number'];
		$dprice=$query['price'];
		$dimg=$query['image'];
		if($dnumber==0){
			exit("<script>
			alert('此商品已暂无存货');
			location.href='index_form.php?flag=".$flag."&username=".$username."';
		</script>");
		}
		$dnum=$dnumber-1;
		if($query2==0){
			$newnum=1;
			if(!mysqli_query($link,"insert into ".$username."(`name`,`d_type`,`number`,`price`,`image`) values ('$dname','$dtype','$newnum','$dprice','$dimg');")||!mysqli_query($link,"update dessert set number=".$dnum." where name='".$name."'")){
				exit("<script>
				alert('失败');
				location.href='index_form.php?flag=".$flag."&username=".$username."';
			</script>");
			}
			
			exit("<script>
			alert('购买成功');
			location.href='index_form.php?flag=".$flag."&username=".$username."';
		</script>");
		}
		echo "2";
		$unum=$unumber+1;
		if(!mysqli_query($link,"update dessert set number=".$dnum." where name='".$dname."'")){
				exit("<script>
				alert('失败1');
				location.href='index_form.php?flag=".$flag."&username=".$username."';
			</script>");
			}
		mysqli_query($link,"update ".$username." set number ='".$unum."' where name='".$dname."'");
			
		exit("<script>
			alert('购买成功');
			location.href='index_form.php?flag=".$flag."&username=".$username."';
		</script>");
		
?>