<?php
$flag=$_GET['flag'];
$username=$_GET['username'];
$name=$_POST["name"];
$type=$_POST["d_type"];
$number=$_POST["number"];
$price=$_POST["price"];
$img=$_POST["filename"];
$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
$flag=false;
	foreach($_POST as $key=>$value){
		if((!isset($key))||($value == '')){
			$flag=false;
		}else{
			$flag=true;
		}
	}
	if($flag==false){
		exit( "<script language=\"JavaScript\">alert(\"表单未填写完毕，请继续填写\");	location.href='insert_dessert_form.php?flag=".$flag."&username=".$username."';</script>");
	}
	$result1=mysqli_query($link,"select * from dessert where name='".$name."'");
	$query=mysqli_num_rows($result1);
	if($query==1){
		exit( "<script language=\"JavaScript\">alert(\"已有此商品，请重新填写\");	location.href='insert_dessert_form.php?flag=".$flag."&username=".$username."';</script>");
	}
	if(!mysqli_query($link,"insert into `dessert` (`name`,`d_type`,`number`,`price`,`image`) values ('$name','$type','$number','$price','$img');")){
		exit( "<script language=\"JavaScript\">alert(\"添加失败，请重新填写\");	location.href='insert_dessert_form.php?flag=".$flag."&username=".$username."';</script>");
	}
	exit( "<script language=\"JavaScript\">alert(\"添加成功\");	location.href='insert_dessert_form.php?flag=".$flag."&username=".$username."';</script>");
?>