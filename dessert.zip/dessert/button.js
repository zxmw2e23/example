
		var btn1=document.getElementById("button1");
		var ck1=document.getElementById("ck1");
		var ck2=document.getElementById("ck2");
		var tj1=document.getElementById("tj1");
		var tj2=document.getElementById("tj2");
		var xj=document.getElementById("xj");
		var sc=document.getElementById("sc");
		var btn2=document.getElementById("button2");
		var btn3=document.getElementById("button3");
		var btn4=document.getElementById("button4");
		
		
		btn1.onclick = function(){
				
			btn1.style.backgroundColor = "#BDBDBD";
			btn2.style.backgroundColor = "";
			btn3.style.backgroundColor = "";
			btn4.style.backgroundColor = "";
				
		}
		ck1.onclick=function(){
			btn1.style.backgroundColor = "";
			btn2.style.backgroundColor = "#BDBDBD";
			btn3.style.backgroundColor = "";
			btn4.style.backgroundColor = "";
		}
		tj1.onclick=function(){
			btn1.style.backgroundColor = "";
			btn2.style.backgroundColor = "#BDBDBD";
			btn3.style.backgroundColor = "";
			btn4.style.backgroundColor = "";
		}
		xj.onclick=function(){
			btn1.style.backgroundColor = "";
			btn2.style.backgroundColor = "#BDBDBD";
			btn3.style.backgroundColor = "";
			btn4.style.backgroundColor = "";
		}
		
		ck2.onclick=function(){
			btn1.style.backgroundColor = "";
			btn2.style.backgroundColor = "";
			btn3.style.backgroundColor = "#BDBDBD";
			btn4.style.backgroundColor = "";
		}
		tj2.onclick=function(){
			btn1.style.backgroundColor = "";
			btn2.style.backgroundColor = "";
			btn3.style.backgroundColor = "#BDBDBD";
			btn4.style.backgroundColor = "";
		}
		sc.onclick=function(){
			btn1.style.backgroundColor = "";
			btn2.style.backgroundColor = "";
			btn3.style.backgroundColor = "#BDBDBD";
			btn4.style.backgroundColor = "";
		}
		btn4.onclick=function(){
			btn1.style.backgroundColor = "";
			btn2.style.backgroundColor = "";
			btn3.style.backgroundColor = "";
			btn4.style.backgroundColor = "#BDBDBD";
		}

