<?php
$flag=$_GET['flag'];
$username=$_GET['username'];

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css" href="form.css" />	
	</head>
	<body style="background: url(./images/regist5.jpg) center;background-size:100% 100%;
background-attachment:fixed;">
		<form action="changetele.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>" method="post">
			<a href="index_form.php?flag=<?php echo $flag;?>&username=<?php echo $username ;?>" style="text-decoration: none;"><h2>←返回主页<h2></a>
			<table>
				<tr><td>新的手机号</td><td><input type="text" name="telephone"></td><td><input type="submit" value="修改"></td></tr>
				
			</table>
			</form>
				</body>
			</html>