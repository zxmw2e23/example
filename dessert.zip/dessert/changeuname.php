<?php
$flag=$_GET['flag'];
$username=$_GET['username'];
$newname=$_POST['newname'];
$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	$result=mysqli_query($link,"select * from dessert_user where username='".$newname."'");
	$query=mysqli_fetch_assoc($result);
	$uname=$query['username'];
	if($uname==$newname){
		exit("<script>
					alert('用户名已存在，请重新填写!');
					location.href='changeuname_form.php?flag=".$flag."&username=".$username."';
				</script>");
	}else {
	if(mysqli_query($link,"update dessert_user set username='".$newname."' where username='".$username."'")){
		if(mysqli_query($link,"rename table ".$username." to ".$newname."")){
			exit("<script>
					alert('更改成功!');
					location.href='change_info_form.php?flag=".$flag."&username=".$newname."';
				</script>");
		}
	}
	
	exit("<script>
				alert('更改失败，请重新填写');
				location.href='change_info_form.php?flag=".$flag."&username=".$username."';
			</script>");
	}
?>