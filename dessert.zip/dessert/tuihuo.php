<?php
$flag=$_GET['flag'];
$name=$_GET['name'];
$username=$_GET['username'];
$link=mysqli_connect('localhost','root','root','dbb_dessert');
	mysqli_set_charset($link,'utf8');
	$result1=mysqli_query($link,"select * from dessert where name='".$name."'");
	$query1=mysqli_fetch_assoc($result1);
	$num1=$query1['number'];
	$num2=$num1+1;
	
	$result2=mysqli_query($link,"select * from ".$username." where name='".$name."'");
	$query2=mysqli_fetch_assoc($result2);
	$number1=$query2['number'];
	
	if($number1==1){
		if(!mysqli_query($link,"delete from ".$username." where name ='".$name."'")||!mysqli_query($link,"update dessert set number =".$num2." where name='".$name."'")){
			
				exit("<script>
						alert('失败,请重新填写');
						location.href='change_info_form.php?flag=".$flag."&username=".$username."';
					</script>");
			
		}
		
			exit("<script>
						alert('退货成功');
						location.href='change_info_form.php?flag=".$flag."&username=".$username."';
					</script>");
	}
	$number2=$number1-1;
	if(!mysqli_query($link,"update ".$username." set number=".$number2." where name='".$name."'")||!mysqli_query($link,"update dessert set number =".$num2." where name='".$name."'")){
		
			exit("<script>
						alert('失败2,请重新填写');
						location.href='change_info_form.php?flag=".$flag."&username=".$username."';
					</script>");
		
	}
	
	exit("<script>
						alert('退货成功');
						location.href='change_info_form.php?flag=".$flag."&username=".$username."';
					</script>");
	
?>